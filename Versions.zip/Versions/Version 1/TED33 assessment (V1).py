# TED33 Assessment
# Luke Anderson

"""
Quiz on basic knowledge of skate boarding
"""

# variables



# imports



# class definition



# main routine